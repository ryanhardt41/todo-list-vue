<template>
  <div class="page-wrapper flex-center">
    Landing Page content here
  </div>
</template>
