<template>
  <div class="page-wrapper flex-center">
    Content for About Page
  </div>
</template>
